# Sreon 1.1 — Linux (ARM64) package

This `.deb` was converted from the official macOS disk image
(`SREONBROWSER.dmg`, Sreon 1.1.0). It installs everything from the Mac
app bundle that is portable, repackaged for ARM64 Linux systems
(aarch64 — Raspberry Pi 4/5 64-bit, Asahi Linux, most ARM SBCs and
ARM servers).

## What is inside

| Path | Contents |
| :--- | :--- |
| `/opt/sreon/engine/` | The SPRFST sources that build Sreon's interface (main, router, omnibox, studio, shield, settings, and 15 more) |
| `/opt/sreon/std/` | SPRFST standard library: `core.spf`, `ai.spf`, `collections.spf`, `testing.spf` |
| `/opt/sreon/examples/` | 21 starter programs, from `01-hello` to `21-neural-network` |
| `/opt/sreon/guidebook/` | The 32-chapter SPRFST guide, as Markdown |
| `/opt/sreon/rules/` | Shield rules (`shield.rules`) |
| `/opt/sreon/splash.html` | The animated celestial splash screen |
| `/usr/bin/sreon` | Launcher — starts the engine when one is installed |
| `/usr/share/icons/hicolor/*/apps/sreon.png` | Orbit mark icons, 16–1024 px |
| `/usr/share/applications/sreon.desktop` | Desktop/menu entry |

## Install

```sh
sudo apt install ./SREONBROWSER-linux-arm64.deb
# or
sudo dpkg -i SREONBROWSER-linux-arm64.deb
```

Verify your machine is ARM64 first:

```sh
dpkg --print-architecture   # should print: arm64
```

## A note about the engine

The Sreon 1.1 macOS build runs two native Mach-O executables — a
WebKit-based window host (`Sreon`) and the SPRFST interpreter
(`sprfst`). Mach-O executables cannot run on Linux, so they are not
part of this package. Everything else from the app bundle is here.

When a linux-arm64 build of the engine is published, drop it into
`/opt/sreon/bin/` as `sreon` (or `sprfst`), make it executable, and
run `sreon` — the launcher finds and starts it automatically.

Until then the payload is yours to explore, in the spirit of SPRFST:
read the code, see how the browser is built, and make something of
your own.

```sh
less /opt/sreon/engine/main.spf
less /opt/sreon/guidebook/01-first-steps.md
```
